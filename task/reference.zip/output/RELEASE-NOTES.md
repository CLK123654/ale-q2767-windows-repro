# 共享构建区安全收紧说明

rendered目录保存三个维护窗口的本地清单。legacy-buildkit由build-platform负责，legacy-vendor由vendor-transition负责，两者在完成迁移前保持现状。

平台管理员选择阶段目录应用后，再查看Namespace标签、目标Pod替换结果与集群准入日志。本地渲染不代表API Server的真实准入结果。
