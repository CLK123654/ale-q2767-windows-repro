# 共享构建区发布说明

current阶段保存变更前清单。legacy-buildkit由build-platform负责，legacy-vendor由vendor-transition负责，两者在完成迁移前保持现状。

维护窗口一次只推进一个阶段。
基线窗口安排在2026-08-18T02:00:00Z至2026-08-18T02:40:00Z，影响范围是build-shared中的cache-writer与test-runner。应用后等待10分钟，再观察20分钟；命中回退条件时由platform-release恢复到current阶段。
收紧窗口安排在2026-08-20T02:00:00Z至2026-08-20T02:50:00Z，影响范围是build-shared中的全部Pod。应用后等待15分钟，再观察25分钟；命中回退条件时由platform-security恢复到baseline阶段。

观察信号：Namespace标签与当前阶段一致
观察信号：目标Pod在等待预算内完成替换
观察信号：构建任务没有新增准入拒绝
回退条件：目标Pod超过等待预算仍未完成替换
回退条件：构建流程出现新增准入拒绝
回退条件：Namespace标签与当前阶段不符
命中任一回退条件时停止本次发布。
